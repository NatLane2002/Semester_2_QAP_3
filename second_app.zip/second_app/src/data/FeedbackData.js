const FeedbackData = [
  {
    id: 1,
    rating: 9,
    text: "Feedback commment 1 - This is a feedback for something...",
  },
  {
    id: 2,
    rating: 10,
    text: "Feedback commment 2 - This is a feedback for something...",
  },
  {
    id: 3,
    rating: 2,
    text: "Feedback commment 3 - This is a feedback for something...",
  },
];

export default FeedbackData;
