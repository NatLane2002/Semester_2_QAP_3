import { createContext, useState, useEffect } from "react";
import axios from "axios";

const FeedbackContext = createContext();

export const FeedbackProvider = ({ children }) => {
  const [feedback, setFeedback] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get("http://localhost:5000/feedbackData");
        setFeedback(response.data);
      } catch (error) {
        // Handle Error, e.g., display an error message
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, []);

  const [feedbackEdit, setFeedbackEdit] = useState({ item: {}, edit: false });

  //   set item to edit here...

  const editFeedback = (item) => {
    // console.log(item);
    setFeedbackEdit({ item, edit: true });
  };

  const updateFeedback = async (id, updItem) => {
    try {
      await axios.put(`http://localhost:5000/feedbackData/${id}`, updItem);
      setFeedback((prevFeedback) =>
        prevFeedback.map((item) =>
          item.id === id ? { ...item, ...updItem } : item
        )
      );
    } catch (error) {
      console.error("Error updating feedback", error);
    }
  };

  const deleteFeedback = async (id) => {
    if (window.confirm("Are you sure you want to delete the feedback?")) {
      try {
        await axios.delete(`http://localhost:5000/feedbackData/${id}`);
        setFeedback((prevFeedback) =>
          prevFeedback.filter((item) => item.id !== id)
        );
      } catch (error) {
        console.error("Error deleting feedback", error);
      }
    }
  };

  const addFeedback = async (newFeedback) => {
    try {
      const response = await axios.post(
        "http://localhost:5000/feedbackData",
        newFeedback
      );
      setFeedback([...feedback, response.data]);
    } catch (error) {
      console.error("Error adding feedback", error);
    }
  };

  return (
    <FeedbackContext.Provider
      value={{
        feedback,
        feedbackEdit,
        deleteFeedback,
        addFeedback,
        editFeedback,
        updateFeedback,
      }}
    >
      {children}
    </FeedbackContext.Provider>
  );
};

export default FeedbackContext;
