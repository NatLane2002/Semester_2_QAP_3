import { Link } from "react-router-dom";

const About = () => {
  return (
    <div className="aboutPage">
      <h1>About Our Review Application</h1>
      <p>
        Welcome to our review application! We are thrilled to have you here. Our
        platform provides a space for users like you to share your valuable
        insights and feedback about products and services that matter to you.
      </p>
      <p>
        Our mission is to empower users to make informed decisions by providing
        a community-driven platform where you can find authentic reviews and
        ratings from fellow consumers.
      </p>
      <h2>Why Reviews Matter</h2>
      <p>
        Reviews are crucial in helping consumers like you make informed choices.
        Your reviews not only assist others in making better decisions but also
        provide valuable feedback to businesses and service providers. Together,
        we can create a thriving community that fosters transparency and
        accountability.
      </p>
      <h2>Join Our Community</h2>
      <p>
        We believe that your voice matters. Join our community of reviewers and
        be part of a movement to shape better products and services. Whether you
        had a wonderful experience or faced challenges, your insights can make a
        significant impact.
      </p>
      <br />
      <p>
        Thank you for being a part of our review application. We hope you enjoy
        exploring reviews, sharing your feedback, and being an essential part of
        our growing community.
      </p>
      <br />
      <p>
        <b>Happy reviewing!</b>
      </p>
      <br />
      <br />
      <center>
        <Link to="/version" className="version-link">
          Version
        </Link>
      </center>
      <br />
    </div>
  );
};

export default About;
