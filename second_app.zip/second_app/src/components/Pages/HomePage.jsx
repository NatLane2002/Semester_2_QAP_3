import FeedbackList from "../FeedbackList";
import FeedbackStats from "../FeedbackStats";
import FeedbackForm from "../FeedbackForm";
import { Link } from "react-router-dom";

const HomePage = () => {
  return (
    <>
      <div className="center">
        <FeedbackForm />
        <FeedbackStats />
        <FeedbackList />
        <br />
        <center>
          <Link to="/version" className="version-link">Version</Link>
        </center>
        <br />
        <br />
      </div>
    </>
  );
};

export default HomePage;
