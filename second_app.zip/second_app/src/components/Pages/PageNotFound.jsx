const PageNotFound = () => {
  return (
    <>
      <div className="pageNotFoundErrorText"><u><b>ERROR 404 - PAGE NOT FOUND</b></u>  <br /> Sorry, the page you are looking for does not exist.</div>
    </>
  );
};

export default PageNotFound;
