import ContactUserInformation from "../ContactUserInformation";
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";

const AdminLogin = () => {
  const [password, setPassword] = useState("");
  const [showContactInfo, setShowContactInfo] = useState(false);
  const [incorrectPassword, setIncorrectPassword] = useState(false);

  const correctPassword = "secret"; // Change this to your desired correct password

  const handleSubmit = (e) => {
    e.preventDefault();

    if (password === correctPassword) {
      setShowContactInfo(true);
      setIncorrectPassword(false);
    } else {
      setIncorrectPassword(true);
      setTimeout(() => {
        setIncorrectPassword(false);
      }, 3000); // Show the "Incorrect password" message for 3 seconds
    }
    setPassword("");
  };

  const handleLockAdminPage = () => {
    setShowContactInfo(false);
  };

  return (
    <>
      <div className="adminLoginUserInfoPage">
        {!showContactInfo && (
          <center>
            <h1>Admin Login</h1>
          </center>
        )}
        {!showContactInfo ? (
          <form className="passwordForm" onSubmit={handleSubmit}>
            <label htmlFor="password"></label>
            <input
              type="password"
              id="password"
              value={password}
              placeholder="Password"
              onChange={(e) => setPassword(e.target.value)}
              required
            />
            <button type="submit">Submit</button>
            {incorrectPassword && (
              <p className="incorrectPasswordMsg">
                Incorrect password. Try again.
              </p>
            )}
          </form>
        ) : (
          <ContactUserInformation handleLockAdminPage={handleLockAdminPage} />
        )}
        <center>
          <br />
          <Link to="/version" className="version-link">
            Version
          </Link>
        </center>
      </div>
    </>
  );
};

export default AdminLogin;
