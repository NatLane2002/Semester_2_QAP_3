import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";

const Settings = () => {
  // Check if there's a theme preference stored in localStorage
  const storedTheme = localStorage.getItem("selectedTheme");
  const [colorTheme, setColorTheme] = useState(storedTheme || "blue");

  const handleChangeColorTheme = (color) => {
    setColorTheme(color);
    // Save the selected theme to localStorage
    localStorage.setItem("selectedTheme", color);
  };

  useEffect(() => {
    // Dynamically update CSS variables in the :root element
    const root = document.documentElement;
    switch (colorTheme) {
      case "dark":
        root.style.setProperty("--main-background-color", "black");
        root.style.setProperty("--text-color", "white");
        root.style.setProperty("--secondary-text-color", "white");
        root.style.setProperty("--privacy-p-color", "white");
        root.style.setProperty("--pages-heading-color", "white");
        root.style.setProperty("--button-background-color", "gray");
        root.style.setProperty("--rating-background-color", "gray");
        root.style.setProperty("--card-background-color", "white");
        root.style.setProperty("--version-link-color", "yellow");
        root.style.setProperty("--form-background-color", "white");
        root.style.setProperty("--hover-button-color", "gray");
        root.style.setProperty("--submit-button-color", "#007bff");
        root.style.setProperty("--submit-button-hover-color", "#0056b3");
        root.style.setProperty("--currently-selected-rating", "green");
        root.style.setProperty(
          "--successfully-submitted-background-color",
          "green"
        );
        break;
      case "light":
        root.style.setProperty("--main-background-color", "white");
        root.style.setProperty("--text-color", "black");
        root.style.setProperty("--secondary-text-color", "darkslategray");
        root.style.setProperty("--privacy-p-color", "black");
        root.style.setProperty("--pages-heading-color", "black");
        root.style.setProperty("--button-background-color", "silver");
        root.style.setProperty("--rating-background-color", "silver");
        root.style.setProperty("--card-background-color", "lightgray");
        root.style.setProperty("--version-link-color", "black");
        root.style.setProperty("--form-background-color", "#c7c7c7");
        root.style.setProperty("--hover-button-color", "black");
        root.style.setProperty("--submit-button-color", "#007bff");
        root.style.setProperty("--submit-button-hover-color", "#0056b3");
        root.style.setProperty("--currently-selected-rating", "green");
        root.style.setProperty(
          "--successfully-submitted-background-color",
          "green"
        );
        break;
      case "blue":
        root.style.setProperty("--main-background-color", "#28536c");
        root.style.setProperty("--text-color", "black");
        root.style.setProperty("--secondary-text-color", "white");
        root.style.setProperty("--privacy-p-color", "white");
        root.style.setProperty("--pages-heading-color", "white");
        root.style.setProperty("--button-background-color", "gray");
        root.style.setProperty("--rating-background-color", "yellow");
        root.style.setProperty("--card-background-color", "white");
        root.style.setProperty("--version-link-color", "yellow");
        root.style.setProperty("--form-background-color", "#c7c7c7");
        root.style.setProperty("--hover-button-color", "black");
        root.style.setProperty("--submit-button-color", "#007bff");
        root.style.setProperty("--submit-button-hover-color", "#0056b3");
        root.style.setProperty("--currently-selected-rating", "green");
        root.style.setProperty(
          "--successfully-submitted-background-color",
          "green"
        );
        break;
      case "orange":
        root.style.setProperty("--main-background-color", "orange");
        root.style.setProperty("--text-color", "black");
        root.style.setProperty("--secondary-text-color", "red");
        root.style.setProperty("--privacy-p-color", "black");
        root.style.setProperty("--pages-heading-color", "red");
        root.style.setProperty("--button-background-color", "red");
        root.style.setProperty("--rating-background-color", "red");
        root.style.setProperty("--card-background-color", "white");
        root.style.setProperty("--version-link-color", "black");
        root.style.setProperty("--form-background-color", "#c7c7c7");
        root.style.setProperty("--hover-button-color", "black");
        root.style.setProperty("--submit-button-color", "darkorange");
        root.style.setProperty("--submit-button-hover-color", "red");
        root.style.setProperty("--currently-selected-rating", "orange");
        root.style.setProperty(
          "--successfully-submitted-background-color",
          "red"
        );
        break;
      case "purple":
        root.style.setProperty("--main-background-color", "purple");
        root.style.setProperty("--text-color", "white");
        root.style.setProperty("--secondary-text-color", "white");
        root.style.setProperty("--privacy-p-color", "white");
        root.style.setProperty("--pages-heading-color", "white");
        root.style.setProperty("--button-background-color", "gray");
        root.style.setProperty("--rating-background-color", "gray");
        root.style.setProperty("--card-background-color", "white");
        root.style.setProperty("--version-link-color", "yellow");
        root.style.setProperty("--form-background-color", "white");
        root.style.setProperty("--hover-button-color", "gray");
        root.style.setProperty("--submit-button-color", "#8e44ad");
        root.style.setProperty("--submit-button-hover-color", "#6c3483");
        root.style.setProperty("--currently-selected-rating", "purple");
        root.style.setProperty(
          "--successfully-submitted-background-color",
          "pink"
        );
        break;
      case "green":
        root.style.setProperty("--main-background-color", "green");
        root.style.setProperty("--text-color", "white");
        root.style.setProperty("--secondary-text-color", "white");
        root.style.setProperty("--privacy-p-color", "white");
        root.style.setProperty("--pages-heading-color", "white");
        root.style.setProperty("--button-background-color", "gray");
        root.style.setProperty("--rating-background-color", "gray");
        root.style.setProperty("--card-background-color", "white");
        root.style.setProperty("--version-link-color", "yellow");
        root.style.setProperty("--form-background-color", "white");
        root.style.setProperty("--hover-button-color", "gray");
        root.style.setProperty("--submit-button-color", "#27ae60");
        root.style.setProperty("--submit-button-hover-color", "#229954");
        root.style.setProperty("--currently-selected-rating", "green");
        root.style.setProperty(
          "--successfully-submitted-background-color",
          "limegreen"
        );
        break;
      // Add 4 more color themes below
      case "pink":
        root.style.setProperty("--main-background-color", "pink");
        root.style.setProperty("--text-color", "black");
        root.style.setProperty("--secondary-text-color", "black");
        root.style.setProperty("--privacy-p-color", "black");
        root.style.setProperty("--pages-heading-color", "black");
        root.style.setProperty("--button-background-color", "gray");
        root.style.setProperty("--rating-background-color", "gray");
        root.style.setProperty("--card-background-color", "white");
        root.style.setProperty("--version-link-color", "black");
        root.style.setProperty("--form-background-color", "white");
        root.style.setProperty("--hover-button-color", "gray");
        root.style.setProperty("--submit-button-color", "#ff66cc");
        root.style.setProperty("--submit-button-hover-color", "#e64db5");
        root.style.setProperty("--currently-selected-rating", "pink");
        root.style.setProperty(
          "--successfully-submitted-background-color",
          "hotpink"
        );
        break;
      case "yellow":
        root.style.setProperty("--main-background-color", "yellow");
        root.style.setProperty("--text-color", "black");
        root.style.setProperty("--secondary-text-color", "black");
        root.style.setProperty("--privacy-p-color", "black");
        root.style.setProperty("--pages-heading-color", "black");
        root.style.setProperty("--button-background-color", "gray");
        root.style.setProperty("--rating-background-color", "lightgray");
        root.style.setProperty("--card-background-color", "white");
        root.style.setProperty("--version-link-color", "black");
        root.style.setProperty("--form-background-color", "white");
        root.style.setProperty("--hover-button-color", "gray");
        root.style.setProperty("--submit-button-color", "#ffd700");
        root.style.setProperty("--submit-button-hover-color", "#c0b300");
        root.style.setProperty("--currently-selected-rating", "yellow");
        root.style.setProperty(
          "--successfully-submitted-background-color",
          "orange"
        );
        break;
      case "cyan":
        root.style.setProperty("--main-background-color", "cyan");
        root.style.setProperty("--text-color", "black");
        root.style.setProperty("--secondary-text-color", "black");
        root.style.setProperty("--privacy-p-color", "black");
        root.style.setProperty("--pages-heading-color", "black");
        root.style.setProperty("--button-background-color", "gray");
        root.style.setProperty("--rating-background-color", "gray");
        root.style.setProperty("--card-background-color", "white");
        root.style.setProperty("--version-link-color", "gray");
        root.style.setProperty("--form-background-color", "white");
        root.style.setProperty("--hover-button-color", "gray");
        root.style.setProperty("--submit-button-color", "#00ffff");
        root.style.setProperty("--submit-button-hover-color", "#575797");
        root.style.setProperty("--currently-selected-rating", "cyan");
        root.style.setProperty(
          "--successfully-submitted-background-color",
          "#575797"
        );
        break;
      default:
        break;
    }
  }, [colorTheme]);

  const themeButtonStyle = {
    fontSize: "20px",
    cursor: "pointer",
    margin: "5px",
    padding: "10px",
    borderRadius: "6px",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    fontWeight: "bold",
  };

  return (
    <div className="settingsPage">
      <h1>Settings</h1>
      <h2>Themes</h2>
      <p>Default</p>
      <div className="settingsContainer">
        <div className="allThemes buttonContainerStyle">
          <button
            className="darkTheme"
            style={{
              ...themeButtonStyle,
              backgroundColor: colorTheme === "dark" ? "gray" : "black",
            }}
            onClick={() => handleChangeColorTheme("dark")}
          >
            Nightfall
          </button>
          <button
            className="lightTheme"
            style={{
              ...themeButtonStyle,
              backgroundColor: colorTheme === "light" ? "gray" : "white",
              color: colorTheme === "light" ? "white" : "black",
            }}
            onClick={() => handleChangeColorTheme("light")}
          >
            Daybreak
          </button>
          <button
            className="blueTheme"
            style={{
              ...themeButtonStyle,
              backgroundColor: colorTheme === "blue" ? "gray" : "#28536c",
              color: colorTheme === "blue" ? "white" : "white",
            }}
            onClick={() => handleChangeColorTheme("blue")}
          >
            Azure Sky
          </button>
        </div>
      </div>
      <p>
        <span className="s">S</span>
        <span className="p">P</span>
        <span className="e">E</span>
        <span className="c">C</span>
        <span className="t">T</span>
        <span className="r">R</span>
        <span className="u">U</span>
        <span className="m">M</span>
      </p>
      <div className="settingsContainer2">
        <div className="allThemes buttonContainerStyle">
          <button
            className="orangeTheme"
            style={{
              ...themeButtonStyle,
              backgroundColor: colorTheme === "orange" ? "gray" : "orange",
              color: colorTheme === "orange" ? "white" : "white",
            }}
            onClick={() => handleChangeColorTheme("orange")}
          >
            Tangerine Tango
          </button>
          <button
            className="purpleTheme"
            style={{
              ...themeButtonStyle,
              backgroundColor: colorTheme === "purple" ? "gray" : "purple",
              color: colorTheme === "purple" ? "white" : "white",
            }}
            onClick={() => handleChangeColorTheme("purple")}
          >
            Royal Amethyst
          </button>
          <button
            className="greenTheme"
            style={{
              ...themeButtonStyle,
              backgroundColor: colorTheme === "green" ? "gray" : "green",
              color: colorTheme === "green" ? "white" : "white",
            }}
            onClick={() => handleChangeColorTheme("green")}
          >
            Enchanted Forest
          </button>
          <button
            className="pinkTheme"
            style={{
              ...themeButtonStyle,
              backgroundColor: colorTheme === "pink" ? "gray" : "pink",
              color: colorTheme === "pink" ? "white" : "white",
            }}
            onClick={() => handleChangeColorTheme("pink")}
          >
            Cotton Candy Dreams
          </button>
          <button
            className="yellowTheme"
            style={{
              ...themeButtonStyle,
              backgroundColor: colorTheme === "yellow" ? "gray" : "yellow",
              color: colorTheme === "yellow" ? "white" : "white",
            }}
            onClick={() => handleChangeColorTheme("yellow")}
          >
            Golden Glow
          </button>
          <button
            className="cyanTheme"
            style={{
              ...themeButtonStyle,
              backgroundColor: colorTheme === "cyan" ? "gray" : "cyan",
              color: colorTheme === "cyan" ? "white" : "white",
            }}
            onClick={() => handleChangeColorTheme("cyan")}
          >
            Aqua Breeze
          </button>
        </div>
      </div>
      <center>
        <br />
        <br />
        <Link to="/version" className="version-link">
          Version
        </Link>
        <br />
        <br />
        <br />
        <br />
      </center>
    </div>
  );
};

export default Settings;
