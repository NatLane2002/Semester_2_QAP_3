import axios from "axios";
import { useState, useEffect } from "react";
import { AiOutlineLock } from "react-icons/ai";
import { FiTrash2 } from "react-icons/fi";
import { BsFillTrashFill } from "react-icons/bs";

const ContactUserInformation = ({ handleLockAdminPage }) => {
  const [contactData, setContactData] = useState([]);
  const [sortingOption, setSortingOption] = useState("");

  const deleteContactData = async (id) => {
    if (window.confirm("Are you sure you want to delete this contact data?")) {
      try {
        await axios.delete(`http://localhost:8000/contactData/${id}`);
        setContactData((prevContactData) =>
          prevContactData.filter((data) => data.id !== id)
        );
      } catch (error) {
        console.error("Error deleting contact data", error);
      }
    }
  };

  const deleteAllContactData = async () => {
    if (
      window.confirm(
        `You are about to delete ALL (${contactData.length}) contacts data. Are you sure you want to continue?`
      )
    ) {
      try {
        console.log("Deleting all contact data...");

        // Get an array of IDs of all contact data objects
        const ids = contactData.map((data) => data.id);

        // Delete each contact data object using its ID
        for (const id of ids) {
          await axios.delete(`http://localhost:8000/contactData/${id}`);
        }

        console.log("All contact data deleted successfully.");
        setContactData([]);
      } catch (error) {
        console.error("Error deleting all contact data:", error);
      }
    }
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get("http://localhost:8000/contactData");
        setContactData(response.data);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, []);

  const sortingOptions = [
    { value: "", label: "Select Sorting Option" },
    { value: "longestMessage", label: "Longest to Shortest" },
    { value: "shortestMessage", label: "Shortest to Longest" },
    { value: "alphabetical", label: "Alphabetical Order by Name" },
  ];

  const handleSortingChange = (event) => {
    setSortingOption(event.target.value);
  };

  const sortContactData = (data) => {
    switch (sortingOption) {
      case "longestMessage":
        return data.sort((a, b) => b.message.length - a.message.length);
      case "shortestMessage":
        return data.sort((a, b) => a.message.length - b.message.length);
      case "alphabetical":
        return data.sort((a, b) =>
          a.firstName.localeCompare(b.firstName, undefined, { sensitivity: "base" })
        );
      default:
        return data;
    }
  };

  const sortedContactData = sortContactData(contactData);

  return (
    <>
      <div>
        <div className="contactInfoHeading"></div>
        <h1>User Contact Information</h1>
        <h2>
          <u>{contactData.length}</u>{" "}
          {contactData.length === 1 ? "Contact" : "Contacts"}
        </h2>
        <div className="select-container">
          <label htmlFor="sortingOptions">Sort By:</label>
          <select
            id="sortingOptions"
            value={sortingOption}
            onChange={handleSortingChange}
          >
            {sortingOptions.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </div>
        <button onClick={handleLockAdminPage} className="invisibleBtn">
          <div className="lockIcon">
            <AiOutlineLock />
          </div>
        </button>
        {contactData.length > 1 && (
          <button className="deleteAllBtn" onClick={deleteAllContactData}>
            <BsFillTrashFill />
          </button>
        )}
        <hr />
        <br />
        {contactData.length === 0 ? (
          <p>No contact data found.</p>
        ) : (
          <ul>
            {sortedContactData.map((data) => (
              <li key={data.id}>
                <strong>Name:</strong> {data.firstName} {data.lastName}
                <br />
                <strong>Email:</strong> {data.email}
                <br />
                <strong>Phone Number:</strong> {data.phoneNumber}
                <br />
                <strong>Message:</strong> {data.message}
                <br />
                <strong>Submission Date:</strong> {data.time}
                <br />
                <br />
                <hr />
                <button
                  onClick={() => deleteContactData(data.id)}
                  className="invisibleBtn"
                >
                  <div className="trashIcon">
                    <FiTrash2 />
                  </div>
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>
    </>
  );
};

export default ContactUserInformation;
