import React, { useEffect, useState } from "react";

const ThemeProvider = ({ children }) => {
  const storedTheme = localStorage.getItem("selectedTheme");
  const [colorTheme, setColorTheme] = useState(storedTheme || "blue");

  useEffect(() => {
    // Dynamically update CSS variables in the :root element
    const root = document.documentElement;
    switch (colorTheme) {
      case "dark":
        root.style.setProperty("--main-background-color", "black");
        root.style.setProperty("--text-color", "white");
        root.style.setProperty("--secondary-text-color", "white");
        root.style.setProperty("--privacy-p-color", "white");
        root.style.setProperty("--pages-heading-color", "white");
        root.style.setProperty("--button-background-color", "gray");
        root.style.setProperty("--rating-background-color", "gray");
        root.style.setProperty("--card-background-color", "white");
        root.style.setProperty("--version-link-color", "yellow");
        root.style.setProperty("--form-background-color", "white");
        root.style.setProperty("--hover-button-color", "gray");
        root.style.setProperty("--submit-button-color", "#007bff");
        root.style.setProperty("--submit-button-hover-color", "#0056b3");
        root.style.setProperty("--currently-selected-rating", "green");
        root.style.setProperty(
          "--successfully-submitted-background-color",
          "green"
        );
        break;
      case "light":
        root.style.setProperty("--main-background-color", "white");
        root.style.setProperty("--text-color", "black");
        root.style.setProperty("--secondary-text-color", "darkslategray");
        root.style.setProperty("--privacy-p-color", "black");
        root.style.setProperty("--pages-heading-color", "black");
        root.style.setProperty("--button-background-color", "silver");
        root.style.setProperty("--rating-background-color", "silver");
        root.style.setProperty("--card-background-color", "lightgray");
        root.style.setProperty("--version-link-color", "black");
        root.style.setProperty("--form-background-color", "#c7c7c7");
        root.style.setProperty("--hover-button-color", "black");
        root.style.setProperty("--submit-button-color", "#007bff");
        root.style.setProperty("--submit-button-hover-color", "#0056b3");
        root.style.setProperty("--currently-selected-rating", "green");
        root.style.setProperty(
          "--successfully-submitted-background-color",
          "green"
        );
        break;
      case "blue":
        root.style.setProperty("--main-background-color", "#28536c");
        root.style.setProperty("--text-color", "black");
        root.style.setProperty("--secondary-text-color", "white");
        root.style.setProperty("--privacy-p-color", "white");
        root.style.setProperty("--pages-heading-color", "white");
        root.style.setProperty("--button-background-color", "gray");
        root.style.setProperty("--rating-background-color", "yellow");
        root.style.setProperty("--card-background-color", "white");
        root.style.setProperty("--version-link-color", "yellow");
        root.style.setProperty("--form-background-color", "#c7c7c7");
        root.style.setProperty("--hover-button-color", "black");
        root.style.setProperty("--submit-button-color", "#007bff");
        root.style.setProperty("--submit-button-hover-color", "#0056b3");
        root.style.setProperty("--currently-selected-rating", "green");
        root.style.setProperty(
          "--successfully-submitted-background-color",
          "green"
        );
        break;
      case "orange":
        root.style.setProperty("--main-background-color", "orange");
        root.style.setProperty("--text-color", "black");
        root.style.setProperty("--secondary-text-color", "red");
        root.style.setProperty("--privacy-p-color", "black");
        root.style.setProperty("--pages-heading-color", "red");
        root.style.setProperty("--button-background-color", "red");
        root.style.setProperty("--rating-background-color", "red");
        root.style.setProperty("--card-background-color", "white");
        root.style.setProperty("--version-link-color", "black");
        root.style.setProperty("--form-background-color", "#c7c7c7");
        root.style.setProperty("--hover-button-color", "black");
        root.style.setProperty("--submit-button-color", "darkorange");
        root.style.setProperty("--submit-button-hover-color", "red");
        root.style.setProperty("--currently-selected-rating", "orange");
        root.style.setProperty(
          "--successfully-submitted-background-color",
          "red"
        );
        break;
      case "purple":
        root.style.setProperty("--main-background-color", "purple");
        root.style.setProperty("--text-color", "white");
        root.style.setProperty("--secondary-text-color", "white");
        root.style.setProperty("--privacy-p-color", "white");
        root.style.setProperty("--pages-heading-color", "white");
        root.style.setProperty("--button-background-color", "gray");
        root.style.setProperty("--rating-background-color", "gray");
        root.style.setProperty("--card-background-color", "white");
        root.style.setProperty("--version-link-color", "yellow");
        root.style.setProperty("--form-background-color", "white");
        root.style.setProperty("--hover-button-color", "gray");
        root.style.setProperty("--submit-button-color", "#8e44ad");
        root.style.setProperty("--submit-button-hover-color", "#6c3483");
        root.style.setProperty("--currently-selected-rating", "purple");
        root.style.setProperty(
          "--successfully-submitted-background-color",
          "pink"
        );
        break;
      case "green":
        root.style.setProperty("--main-background-color", "green");
        root.style.setProperty("--text-color", "white");
        root.style.setProperty("--secondary-text-color", "white");
        root.style.setProperty("--privacy-p-color", "white");
        root.style.setProperty("--pages-heading-color", "white");
        root.style.setProperty("--button-background-color", "gray");
        root.style.setProperty("--rating-background-color", "gray");
        root.style.setProperty("--card-background-color", "white");
        root.style.setProperty("--version-link-color", "yellow");
        root.style.setProperty("--form-background-color", "white");
        root.style.setProperty("--hover-button-color", "gray");
        root.style.setProperty("--submit-button-color", "#27ae60");
        root.style.setProperty("--submit-button-hover-color", "#229954");
        root.style.setProperty("--currently-selected-rating", "green");
        root.style.setProperty(
          "--successfully-submitted-background-color",
          "limegreen"
        );
        break;
      // Add 4 more color themes below
      case "pink":
        root.style.setProperty("--main-background-color", "pink");
        root.style.setProperty("--text-color", "black");
        root.style.setProperty("--secondary-text-color", "black");
        root.style.setProperty("--privacy-p-color", "black");
        root.style.setProperty("--pages-heading-color", "black");
        root.style.setProperty("--button-background-color", "gray");
        root.style.setProperty("--rating-background-color", "gray");
        root.style.setProperty("--card-background-color", "white");
        root.style.setProperty("--version-link-color", "black");
        root.style.setProperty("--form-background-color", "white");
        root.style.setProperty("--hover-button-color", "gray");
        root.style.setProperty("--submit-button-color", "#ff66cc");
        root.style.setProperty("--submit-button-hover-color", "#e64db5");
        root.style.setProperty("--currently-selected-rating", "pink");
        root.style.setProperty(
          "--successfully-submitted-background-color",
          "hotpink"
        );
        break;
      case "yellow":
        root.style.setProperty("--main-background-color", "yellow");
        root.style.setProperty("--text-color", "black");
        root.style.setProperty("--secondary-text-color", "black");
        root.style.setProperty("--privacy-p-color", "black");
        root.style.setProperty("--pages-heading-color", "black");
        root.style.setProperty("--button-background-color", "gray");
        root.style.setProperty("--rating-background-color", "lightgray");
        root.style.setProperty("--card-background-color", "white");
        root.style.setProperty("--version-link-color", "black");
        root.style.setProperty("--form-background-color", "white");
        root.style.setProperty("--hover-button-color", "gray");
        root.style.setProperty("--submit-button-color", "#ffd700");
        root.style.setProperty("--submit-button-hover-color", "#c0b300");
        root.style.setProperty("--currently-selected-rating", "yellow");
        root.style.setProperty(
          "--successfully-submitted-background-color",
          "orange"
        );
        break;
      case "cyan":
        root.style.setProperty("--main-background-color", "cyan");
        root.style.setProperty("--text-color", "black");
        root.style.setProperty("--secondary-text-color", "black");
        root.style.setProperty("--privacy-p-color", "black");
        root.style.setProperty("--pages-heading-color", "black");
        root.style.setProperty("--button-background-color", "gray");
        root.style.setProperty("--rating-background-color", "gray");
        root.style.setProperty("--card-background-color", "white");
        root.style.setProperty("--version-link-color", "gray");
        root.style.setProperty("--form-background-color", "white");
        root.style.setProperty("--hover-button-color", "gray");
        root.style.setProperty("--submit-button-color", "#00ffff");
        root.style.setProperty("--submit-button-hover-color", "#575797");
        root.style.setProperty("--currently-selected-rating", "cyan");
        root.style.setProperty(
          "--successfully-submitted-background-color",
          "#575797"
        );
        break;
      default:
        break;
    }
  }, [colorTheme]);
  
  return <> {children} </>;
};

export default ThemeProvider;
