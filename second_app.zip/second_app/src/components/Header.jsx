import PropTypes from "prop-types";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";

const Header = ({ text, bgColor, textColor }) => {
  const headerStyle = {
    backgroundColor: bgColor,
    color: textColor,
  };

  return (
    <>
      <div>
        <header style={headerStyle}>
          {text}
          <Link to="/" className="link">
            Home
          </Link>
          <Link to="/about" className="link">
            About
          </Link>
          <Link to="/contact" className="link">
            Contact
          </Link>
          <Link to="/policy" className="link">
            Policy
          </Link>
          <Link to="/settings" className="link">
            Settings
          </Link>
        </header>
      </div>
    </>
  );
};

Header.defaultProps = {
  text: "Feedback App",
  bgColor: "rgba(0,0,0,0.5)",
  textColor: "#f3f31c",
};

Header.propTypes = {
  text: PropTypes.string,
  bgColor: PropTypes.string,
  textColor: PropTypes.string,
};

export default Header;
