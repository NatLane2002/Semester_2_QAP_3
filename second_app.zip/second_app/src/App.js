import "./App.css";
import Header from "./components/Header";
import HomePage from "./components/Pages/HomePage";
import { FeedbackProvider } from "./context/FeedbackContext";
import ProjectVersion from "./components/Pages/ProjectVersion";
import PageNotFound from "./components/Pages/PageNotFound";
import Contact from "./components/Pages/Contact";
import About from "./components/Pages/About";
import PrivacyPolicyAndTerms from "./components/Pages/PrivacyPolicyAndTerms";
import AdminLogin from "./components/Pages/AdminLogin"
import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import Settings from "./components/Pages/Settings";

function App() {
  return (
    <FeedbackProvider>
      <>
        <Header />
        <div className="container">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/about" element={<About />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/policy" element={<PrivacyPolicyAndTerms />} />
            <Route path="/settings" element={<Settings />} />
            <Route path="/version" element={<ProjectVersion />} />
            <Route path="/adminlogin" element={<AdminLogin />} />
            <Route path="*" element={<PageNotFound />} />
          </Routes>
        </div>
      </>
    </FeedbackProvider>
  );
}

export default App;
